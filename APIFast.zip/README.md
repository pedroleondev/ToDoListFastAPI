# ToDoListFastAPI
 Aplicação de To Do List utilizando FastAPI
