from fastapi import FastAPI
from api.routes.todolist import todolist_router
# Criando instancia do FastAPI
app = FastAPI(title="TO DO LIST API", version="0.1.0")
app.include_router(todolist_router)

# Rota principal
@app.get("/")

def index():
    return {"status": "TO DO LIST API is running!!!"}
