from sqlalchemy import Column, Integer, String
from datetime import datetime, timezone
from api.databases.database import Base

class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    description = Column(String)
    state = Column(String)
    created_at = Column(datetime, default=datetime.now(timezone.utc))
    updated_at = Column(datetime, default=datetime.now(timezone.utc))