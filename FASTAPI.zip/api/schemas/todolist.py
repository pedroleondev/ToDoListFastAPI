from pydantic import BaseModel, Field
from datetime import datetime, timezone

class TodoBase(BaseModel):
    title: str
    description: str | None = Field(default=None, max_length=100)

class TodoCreate(TodoBase):
    pass

class Todo(TodoBase):
    id: int
    created_at: datetime = Field(default_factory=datetime.now(timezone.utc))